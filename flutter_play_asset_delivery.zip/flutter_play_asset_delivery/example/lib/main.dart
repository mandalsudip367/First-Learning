import 'dart:io';
import 'package:flutter/material.dart';
import 'dart:async';

import 'package:flutter_play_asset_delivery/flutter_play_asset_delivery.dart';
import 'package:fluttertoast/fluttertoast.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(home: HomeScreen());
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<File> image;
  Map<String, dynamic>? _currentStatus;
  final te = TextEditingController();
  String? isExist;

  @override
  void initState() {
    super.initState();
    checkDownload();
  }

  checkDownload() async {
    isExist = await FlutterPlayAssetDelivery.getAssetLocation(
        'fast_follow_asset_pack', 'dog_gallery_cropped/1.jpg');
    Fluttertoast.showToast(msg: "isExist $isExist");
    // if (isExist == null) {
    initAssetPackStatusListener();
    FlutterPlayAssetDelivery.fetchFastFollowAsset('fast_follow_asset_pack');
    // }
    setState(() {});
  }

  void initAssetPackStatusListener() {
    // Register the listener to get updates
    FlutterPlayAssetDelivery.registerListener();

    // Listen for asset pack status updates
    FlutterPlayAssetDelivery.assetPackStatusStream.listen((statusInfo) async {
      if (statusInfo['status'].toString().toLowerCase() == "completed") {
        isExist = await FlutterPlayAssetDelivery.getAssetLocation(
            'fast_follow_asset_pack', 'dog_gallery_cropped/1.jpg');
      }
      setState(() {
        _currentStatus = statusInfo;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Plugin example app'),
      ),
      body: Center(
        child: isExist != null
            ? ListView.builder(
                itemCount: 300,
                itemBuilder: (context, index) => Image.file(File(
                    'data/data/com.example.min_asset_size/files/assetpacks/fast_follow_asset_pack/1/1/assets/dog_gallery_cropped/${index + 1}.jpg')),
              )
            : _currentStatus != null
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Pack Name: ${_currentStatus!['packName']}"),
                      Text("Status: ${_currentStatus!['status']}"),
                      if (_currentStatus!.containsKey('progress'))
                        Text("Progress: ${_currentStatus!['progress']}%"),
                    ],
                  )
                : const Text("Waiting for asset pack status updates..."),
      ),
    );
  }
}

class ImageViewer extends StatelessWidget {
  final String imageFile;
  const ImageViewer({super.key, required this.imageFile});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future:
            FlutterPlayAssetDelivery.getPackLocation("fast_follow_asset_pack"),
        builder: (_, AsyncSnapshot<String?> snapshot) {
          if (snapshot.hasError) {
            return Text('Has Error ${snapshot.error}');
          }
          if (!snapshot.hasData) {
            return const SizedBox(
                height: 100,
                width: 100,
                child: Center(child: CircularProgressIndicator()));
          }
          if (snapshot.hasData) {
            if (snapshot.data != null) {
              return Column(mainAxisSize: MainAxisSize.min, children: [
                Image.file(
                  File(
                    snapshot.data!,
                  ),
                  height: 200,
                ),
                SelectableText(imageFile)
              ]);
            } else {
              return const Text('Waiting');
            }
          }
          return const Text('Waiting');
        },
      ),
    );
  }
}
