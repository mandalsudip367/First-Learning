//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_play_asset_delivery/FlutterPlayAssetDeliveryPlugin.h>)
#import <flutter_play_asset_delivery/FlutterPlayAssetDeliveryPlugin.h>
#else
@import flutter_play_asset_delivery;
#endif

#if __has_include(<fluttertoast/FluttertoastPlugin.h>)
#import <fluttertoast/FluttertoastPlugin.h>
#else
@import fluttertoast;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterPlayAssetDeliveryPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterPlayAssetDeliveryPlugin"]];
  [FluttertoastPlugin registerWithRegistrar:[registry registrarForPlugin:@"FluttertoastPlugin"]];
}

@end
