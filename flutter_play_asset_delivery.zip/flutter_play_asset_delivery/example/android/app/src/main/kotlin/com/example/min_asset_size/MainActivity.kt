package com.example.min_asset_size

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
