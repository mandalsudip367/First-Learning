#import <Flutter/Flutter.h>

@interface FlutterPlayAssetDeliveryPlugin : NSObject<FlutterPlugin>
@end
