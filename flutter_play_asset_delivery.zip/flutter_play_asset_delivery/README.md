# flutter_play_asset_delivery
[Google Play asset delivery docs](https://developer.android.com/guide/playcore/asset-delivery)
This plugin allows us to upload appbundles with > 150 MB to the play store.
Follow the instructions to setup the asset delivery.
[Setup instructions](https://developer.android.com/guide/playcore/asset-delivery/integrate-java)

## For Testing

java -jar bundletool-all.jar build-apks --bundle=path/to/your/bundle.aab \--output=output.apks --local-testing


// A real command would look like :

java -jar bundletool-all-1.6.1.jar build-apks --bundle=/home/mind/AndroidStudioProjects/PlayAssetDeliveryDemo/app/release/app-release.aab \--output=pad.apks --local-testing



java -jar bundletool.jar install-apks --apks=output.apks


// A real command for installing generated APK would look like

java -jar bundletool-all-1.6.1.jar install-apks --apks=pad.apks


or Upload aab into internal testing

[Setup instructions](https://medium.com/mindful-engineering/google-play-asset-delivery-in-android-dcc2059e5a63)


## Systems
- [x] Android
- [ ] iOS alternative

## Test assets
Edit Run/Debug configurations for Android and change *Deploy* to *APK from app bundle*
