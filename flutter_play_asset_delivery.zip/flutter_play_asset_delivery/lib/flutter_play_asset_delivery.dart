import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class FlutterPlayAssetDelivery {
  static const MethodChannel _channel =
      MethodChannel('flutter_play_asset_delivery');

  static Future<String?> getAssetLocation(
      String packName, String assetPath) async {
    try {
      final String? assetLocation = await _channel.invokeMethod<String>(
        'getAssetLocation',
        {'packName': packName, 'assetPath': assetPath},
      );
      return assetLocation;
    } on PlatformException catch (e) {
      debugPrint("Failed to get asset location: '${e.message}'.");
      return null;
    }
  }

  static Future<String?> getPackLocation(String packName) async {
    try {
      final String? assetLocation = await _channel.invokeMethod<String>(
        'getPackLocation',
        {'packName': packName},
      );
      return assetLocation;
    } on PlatformException catch (e) {
      debugPrint("Failed to get asset location: '${e.message}'.");
      return null;
    }
  }

  static Future<void> fetchFastFollowAsset(String packName) async {
    try {
      await _channel.invokeMethod('fetchFastFollowAsset', packName);
    } on PlatformException catch (e) {
      debugPrint("Failed to fetch asset pack: ${e.message}");
    }
  }

  static final StreamController<Map<String, dynamic>> _statusController =
      StreamController.broadcast();

  static Stream<Map<String, dynamic>> get assetPackStatusStream =>
      _statusController.stream;

  // Register a listener for asset pack status updates
  static void registerListener() {
    _channel.setMethodCallHandler((call) async {
      if (call.method == 'onAssetPackStatus') {
        Map<String, dynamic> statusInfo =
            Map<String, dynamic>.from(call.arguments);
        _statusController.add(statusInfo); // Send status info to the stream
      }
    });
  }

  static void dispose() {
    _statusController.close();
  }
}
