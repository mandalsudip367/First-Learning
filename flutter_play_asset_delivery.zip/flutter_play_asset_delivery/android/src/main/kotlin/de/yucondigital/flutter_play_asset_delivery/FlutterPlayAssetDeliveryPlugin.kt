package de.yucondigital.flutter_play_asset_delivery

import android.app.Activity
import android.content.Context
import android.content.res.AssetManager
import android.util.Log
import android.widget.Toast
import androidx.annotation.NonNull
import com.google.android.play.core.assetpacks.AssetLocation
import com.google.android.play.core.assetpacks.AssetPackLocation
import com.google.android.play.core.assetpacks.AssetPackManager
import com.google.android.play.core.assetpacks.AssetPackManagerFactory
import com.google.android.play.core.assetpacks.AssetPackStateUpdateListener
import com.google.android.play.core.assetpacks.model.AssetPackStatus
import com.google.android.play.core.ktx.totalBytes

import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.systemchannels.SettingsChannel.CHANNEL_NAME
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import io.flutter.plugin.common.PluginRegistry
import java.io.File
import java.io.IOException

/** FlutterPlayAssetDeliveryPlugin */
class FlutterPlayAssetDeliveryPlugin: FlutterPlugin, MethodCallHandler {
  private lateinit var channel : MethodChannel
  private lateinit var context: Context
  private lateinit var assetPackManager: AssetPackManager
  private val assetPackStateUpdateListener = AssetPackStateUpdateListener { state ->
    val packName = state.name()
    when (state.status()) {
      AssetPackStatus.COMPLETED -> {

        Log.d("Asset Listener", "Download Complete")

        // Notify Flutter that the asset pack is ready
        channel.invokeMethod("onAssetPackStatus", mapOf("packName" to packName, "status" to "COMPLETED"))
        Toast.makeText(context,"Download Completed",Toast.LENGTH_LONG).show()
      }
      AssetPackStatus.FAILED -> {
        Log.d("Asset Listener", "Download Failed")

        // Notify Flutter about failure
        channel.invokeMethod("onAssetPackStatus", mapOf("packName" to packName, "status" to "FAILED"))
      }
      AssetPackStatus.PENDING -> {
        Log.d("Asset Listener", "Pending")

        // Notify Flutter that the download is pending
        channel.invokeMethod("onAssetPackStatus", mapOf("packName" to packName, "status" to "PENDING"))
      }
      AssetPackStatus.DOWNLOADING -> {
        // Calculate download progress as a percentage
        val totalBytes = state.totalBytesToDownload()
        val downloadedBytes = state.bytesDownloaded()
        val progress = if (totalBytes > 0) (100 * downloadedBytes / totalBytes).toInt() else 0

        Log.d("Asset Listener", "Download Staring $progress")

        // Send download progress to Flutter
        channel.invokeMethod("onAssetPackStatus", mapOf("packName" to packName, "status" to "DOWNLOADING", "progress" to progress))
        Toast.makeText(context,"Download Staring $progress",Toast.LENGTH_LONG).show()
      }
      AssetPackStatus.CANCELED -> {
        // Notify Flutter about cancellation
        Log.d("Asset Listener", "Canceled")
        channel.invokeMethod("onAssetPackStatus", mapOf("packName" to packName, "status" to "CANCELED"))
      }
      AssetPackStatus.TRANSFERRING -> {
        // Notify Flutter that the asset pack is being transferred
        Log.d("Asset Listener", "Transfering")
        val transferProgress = state.transferProgressPercentage()
        channel.invokeMethod("onAssetPackStatus", mapOf("packName" to packName, "status" to "TRANSFERRING", "progress" to transferProgress))
        Toast.makeText(context,"Transfering Staring $transferProgress",Toast.LENGTH_LONG).show()
      }
      else -> {
        Log.d("Asset Listener", "Nothing")
        // Handle other statuses and notify Flutter
        channel.invokeMethod("onAssetPackStatus", mapOf("packName" to packName, "status" to "UNKNOWN", "code" to state.status()))
        Toast.makeText(context,"Noting Staring",Toast.LENGTH_LONG).show()
      }
    }
  }

  override fun onAttachedToEngine(@NonNull flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
    context = flutterPluginBinding.applicationContext
    assetPackManager = AssetPackManagerFactory.getInstance(flutterPluginBinding.applicationContext)
    assetPackManager.registerListener(assetPackStateUpdateListener)
    channel = MethodChannel(flutterPluginBinding.binaryMessenger, "flutter_play_asset_delivery")
    channel.setMethodCallHandler(this)
  }

  override fun onMethodCall(@NonNull call: MethodCall, @NonNull result: Result) {

    when (call.method) {
      "fetchFastFollowAsset" -> {
        val packName: String = call.arguments.toString()
        fetchFastFollowAsset(packName)
        result.success(null)
      }
      "getAssetLocation" -> {
        val packName = call.argument<String>("packName")
        val assetPath = call.argument<String>("assetPath")

        if (packName != null && assetPath != null) {
          val assetFileLocation = getAssetLocation(packName, assetPath)
          if (assetFileLocation != null) {
            result.success(assetFileLocation.absolutePath)
          } else {
            result.error("ASSET_NOT_FOUND", "Asset not found in the asset pack", null)
          }
        } else {
          result.error("INVALID_ARGUMENTS", "Invalid arguments", null)
        }
      }
      "getPackLocation" -> {
        val packName = call.argument<String>("packName")

        if (packName != null) {
          val assetFileLocation = getPackLocation(packName)
          if (assetFileLocation != null) {
            result.success(assetFileLocation)
          } else {
            result.success(null)
          }
        } else {
          result.success(null)
        }
      }
      else -> {
        result.notImplemented()
      }
    }
  }

  private fun fetchFastFollowAsset(packName: String) {
    try {
      val availablePacks = assetPackManager.getPackStates(listOf(packName)).isComplete
      Toast.makeText(context,availablePacks.toString(),Toast.LENGTH_LONG).show()
      Log.d("IsAvalaibles", "$availablePacks")
    }catch(e: IOException) {
      Toast.makeText(context,e.message,Toast.LENGTH_LONG).show()
      Log.d("IsAvalaibles", e.message.toString())
    }

    assetPackManager.fetch(listOf(packName)).addOnSuccessListener {
      Toast.makeText(context,it.totalBytes.toString(),Toast.LENGTH_LONG).show()
      Log.d("FlutterPlayAsset", "Fast-follow asset pack $packName is downloading.")
    }.addOnFailureListener {
      Toast.makeText(context,it.message,Toast.LENGTH_LONG).show()
      Log.e("FlutterPlayAsset", "Failed to download asset pack $packName.${it.message}")
    }
  }

  private fun getAssetLocation(packName: String, assetPath: String): File? {
    // Get the location of the asset pack
    val packLocation: AssetPackLocation? = assetPackManager.getPackLocation(packName)
    if (packLocation == null) {
      Log.e("FlutterPlayAsset", "Asset pack $packName not found or not downloaded.")
      return null
    }
    Toast.makeText(context,"P ${packLocation.assetsPath()}",Toast.LENGTH_LONG).show()
    // Get the full path of the specific asset within the asset pack
    val assetFileLocation = File(packLocation.assetsPath(), assetPath)

    // Check if the file exists
    if (assetFileLocation.exists()) {
      return assetFileLocation
    } else {
      Log.e("FlutterPlayAsset", "Asset $assetPath not found in pack $packName.")
      Toast.makeText(context,"Asset $assetPath not found in pack $packName.",Toast.LENGTH_LONG).show()
      return null
    }
  }

  private fun getPackLocation(packName: String): String? {
    // Get the location of the asset pack
    val packLocation: AssetPackLocation? = assetPackManager.getPackLocation(packName)

    return if (packLocation != null) {
      Log.e("FlutterPlayAsset", "Asset pack $packName not found or not downloaded.")
      packLocation.assetsPath()
    }else{
      null;
    }
  }


  override fun onDetachedFromEngine(@NonNull binding: FlutterPlugin.FlutterPluginBinding) {
    assetPackManager.unregisterListener(assetPackStateUpdateListener)
    channel.setMethodCallHandler(null)
  }
}
