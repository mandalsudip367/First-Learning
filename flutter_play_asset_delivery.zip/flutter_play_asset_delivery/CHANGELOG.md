## 0.0.1

### Current supported delivery modes in this version
- [x] install-time
- [ ] fast-follow
- [ ] on-demand